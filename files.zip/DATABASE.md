# DATABASE.md

Schema, data sourcing, and migration approach for the Census Analytics Platform. See `ARCHITECTURE.md` for how this fits into the overall system.

---

## 1. Design principle: tall/long fact table

Rather than one wide table with a column per metric, all metric data lives in a single tall table (`fact_values`): one row per `(locale, measure, year)` combination. This is what lets both tabs, and every preset query, run off one generic query shape (`filter by locale list + year, join to measure`) instead of needing bespoke logic per metric. It also means adding a new metric later is a data-insert operation, not a schema migration.

---

## 2. Tables

### `locales`
One row per state or Union Territory.

| Column | Type | Notes |
|---|---|---|
| `id` | integer, PK | |
| `iso_code` | string(4), unique, indexed | ISO 3166-2:IN code, e.g. `MH`, `GJ` — the standard used for labeling on the map and for API parameters, guarantees uniqueness across states/UTs |
| `name` | string(100) | e.g. "Maharashtra" |
| `type` | string(10) | `"state"` or `"ut"` |
| `centroid_lat`, `centroid_lng` | float | used for map label placement / quick-zoom shortcuts |

### `measures`
One row per metric definition.

| Column | Type | Notes |
|---|---|---|
| `id` | integer, PK | |
| `code` | string(50), unique, indexed | e.g. `literacy_rate`, `population`, `sex_ratio` |
| `name` | string(100) | display name, e.g. "Literacy Rate" |
| `unit` | string(30) | e.g. `%`, `people`, `per km2` |
| `category` | string(50) | one of: `demographics`, `economy`, `literacy`, `health`, `infrastructure` — drives Tab 2's category sidebar |
| `higher_is_better` | boolean, nullable | `true` = higher is better (literacy rate), `false` = lower is better (infant mortality), `null` = non-directional (population, area). **Required** — the Tab 2 verdict card and ranking badges cannot function without this being set correctly for every measure. |

### `fact_values`
The tall fact table — the single source of truth for every number shown on either tab.

| Column | Type | Notes |
|---|---|---|
| `id` | integer, PK | |
| `locale_id` | FK → `locales.id` | |
| `measure_id` | FK → `measures.id` | |
| `year` | integer | `2011` for all current data; schema already supports other years without change |
| `value` | float | |

Constraint: `UNIQUE(locale_id, measure_id, year)` — one value per locale/measure/year combination, no duplicates.

**Indexing note:** add an index on `(measure_id, year, value)` — this is what makes the Tab 2 "closest state by metric" preset query (an `ORDER BY ABS(value - anchor_value)` sort) and the national ranking computation (`RANK() OVER (PARTITION BY measure_id, year ORDER BY value DESC)`) efficient as the dataset grows. Not strictly necessary at current data volume (a few hundred rows), but cheap to add now.

### `state_adjacency`
Static reference table for Tab 2's "Neighboring State" preset. Populated once from official boundary data, not derived at query time.

| Column | Type | Notes |
|---|---|---|
| `id` | integer, PK | |
| `state_code` | string(4), indexed | |
| `neighbor_code` | string(4) | |
| `shared_border_length` | float | used to pick the best neighbor when a state has several — longest shared border wins, not an unrelated metric like population |

Island states (Andaman & Nicobar, Lakshadweep) have no rows in this table where they are `state_code` — the preset endpoint returns a null result for them, and the frontend disables the "Neighboring State" preset button with a tooltip rather than treating this as an error.

---

## 3. Migrations

All schema changes go through Alembic (`alembic revision --autogenerate -m "description"`, then `alembic upgrade head`). Never modify the schema with a manual `ALTER TABLE` outside of a tracked migration — this is what keeps the schema reproducible across environments and reversible if a change turns out to be wrong.

---

## 4. Data sourcing

- **Metric data** (population, density, sex ratio, literacy rate, etc.): sourced from official Census of India tables (censusindia.gov.in), state-level, 2011.
- **Boundary/GeoJSON data**: sourced from Survey of India or the Census of India's own GIS shapefiles — a single authoritative source used for both the national and focused-state map views, to avoid border mismatches that come from mixing an official source with third-party map packages.
- **State adjacency data**: derived once from the same official boundary source (which states share a border, and the length of that shared border), not from a third-party adjacency list.

Do not substitute a convenient third-party GeoJSON npm package for the boundary data — this was an explicit decision in `DESIGN.md`, not an oversight.

---

## 5. Seed script

A one-off Python script (`backend/scripts/seed.py`, to be written in Phase 1) reads the sourced CSVs/shapefiles and populates `locales`, `measures`, and `fact_values`. This is a script to be run once (and re-run if data needs reloading), not application code that runs on every startup.

---

## 6. Boundary data preprocessing

The raw official boundary data is simplified once, offline, via `mapshaper` into two static files:
- A simplified version (far fewer coordinate points) for the national zoomed-out view.
- The full-detail version, loaded only when a user clicks into a specific state's focused view.

This preprocessing step happens outside the running application — it's a build-time/data-prep task, not something computed live in the browser or the API.

---

## 7. Future extension (not built yet, but the schema anticipates it)

- **Multi-year data**: the `year` column on `fact_values` already supports this — adding a second census year is a data-load operation, not a schema change.
- **RBAC tables** (`users`, `roles`, `role_permissions`, `audit_log`): described fully in `RBAC.md`, not created until Phase 7.
